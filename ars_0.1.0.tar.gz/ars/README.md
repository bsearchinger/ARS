# ars
Adaptive Rejection Sampling Package for Stat 243 Final Project

Authors:  Brian Collica,
          Ashish Ramesh,
          Ben Searchinger
